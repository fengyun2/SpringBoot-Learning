package com.win.springbootspringdocopenapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSpringdocOpenapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
