package com.win.springbootspringdocopenapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSpringdocOpenapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSpringdocOpenapiApplication.class, args);
	}

}
